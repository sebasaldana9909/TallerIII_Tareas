let totalPts = 10;
let steps = totalPts + 1;
var canvas;
var x = 0;
var y = 0;

function setup() {
  canvas = createCanvas(820, 600);
  canvas.position(1000, 50);
  frameRate(60);
}

function draw() {
  background(0);
  
  x = lerp(x, mouseX, 0.05);
  y = lerp(y, mouseY, 0.05);
  let rand = 0;
  
  for (let i = 1; i < steps; i++) {
    // point((width / steps) * i, height / 2 + random(-rand, rand));
    circle((x / steps)* i, y / 2 + random(-rand, rand), 20)
    fill("#FFDE05")
    rand += random(-8, 6);
  }
}
