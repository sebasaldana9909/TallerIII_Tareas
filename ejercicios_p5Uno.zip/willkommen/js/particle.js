let system;

var r, canvas;
var g;
var b;
var hola = 500;

function setup() {
 canvas = createCanvas(850, 750);
 canvas.position(1100, 50)
  system = new ParticleSystem(createVector(width / 2, 50));
}

function draw() {
  background(255);
  system.addParticle();
  system.run();
}

// A simple Particle class
let Particle = function(position) {
  this.acceleration = createVector(0, 0.05);
  this.velocity = createVector(random(-1, -20), random(-1, 10));
  this.position = position.copy();
  this.lifespan = 300;
};

Particle.prototype.run = function() {
  this.update(mouseX,);
  this.display();
};

// Method to update position
Particle.prototype.update = function(){
  this.velocity.add(this.acceleration);
  this.position.add(this.velocity);
  this.lifespan -= 1;
};

// Method to display
Particle.prototype.display = function() {
  stroke(200, this.lifespan);
  strokeWeight(2);
  r = random(116, this.lifespan);
  g = random(196);
  b = random (255);
  fill(r, g, b, this.lifespan);
  rect(this.position.x, this.position.y, 80, 80);
};

// Is the particle still useful?
Particle.prototype.isDead = function(){
  return this.lifespan < 0;
};

let ParticleSystem = function(position) {
  this.origin = position.copy();
  this.particles = [];
};

ParticleSystem.prototype.addParticle = function() {
  this.particles.push(new Particle(this.origin));
};

ParticleSystem.prototype.run = function() {
  for (let i = this.particles.length-1; i >= 0; i--) {
    let p = this.particles[i];
    p.run();
    if (p.isDead()) {
      this.particles.splice(i, 1);
    }
  }
};