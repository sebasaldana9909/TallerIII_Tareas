var max_distancia;
var canvas;
var v = 0;
var l = 0;

function setup(){
    canvas = createCanvas (1120, 900);
    canvas.position(800 ,50)
    noStroke();
    max_distancia = dist(0, 0, width, height);
}

function draw() {
    background(255, 222, 5);
  
    for (let i = 0; i <= width; i += 30) {
      for (let j = 0; j <= height; j += 30) {
        let size = dist(mouseX, mouseY, i, j);
        size = (size / max_distancia) * 40;
       rect(i, j, size, size);
      }
    }
    
    v = lerp(v, mouseX, 0.05);
    l = lerp(l, mouseY, 0.05);
  
    fill(255);
    stroke(255);
    triangle(v, 66, v, l, l , 66); 
    
   
  }

